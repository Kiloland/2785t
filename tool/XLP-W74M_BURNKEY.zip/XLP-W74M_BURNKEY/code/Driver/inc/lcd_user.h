#ifndef __LCD_USER_H_
#define __LCD_USER_H_

#include "Nano1X2Series.h"
#include "type.h"

extern void Lcd_Configuration(void);


#endif



