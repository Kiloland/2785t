#ifndef __LED_H_
#define __LED_H_


#include "type.h"
#include "Nano1X2Series.h"



#define LED_GREEN   PE6

extern uint8 gb_LedActiveCnt;
extern uint16 gb_LedBlinkTime,gb_LedCnt;




extern void Led_Io_Init(void);
extern void Led_Blink(uint16 Blink_Time,uint8 Blink_Cnt);
extern void Task_LedISR(void);

#endif




