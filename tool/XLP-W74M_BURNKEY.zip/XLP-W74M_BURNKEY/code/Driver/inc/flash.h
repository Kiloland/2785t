#ifndef __FLASH_H_
#define __FLASH_H_

#include "M480.h"
#include "type.h"


#define FLASH_CS_OUT_HIGH  (PC3 =1)
#define FLASH_CS_OUT_LOW   (PC3 =0)

#define FLASH_WP_OUT_HIGH  (PC5 =1)
#define FLASH_WP_OUT_LOW   (PC5 =0)

#define FLASH_HOLD_OUT_HIGH  (PC4 =1)
#define FLASH_HOLD_OUT_LOW   (PC4 =0)


#define FLASH_CMD_READ_MANID        0X90 //������ID
#define FLASH_CMD_WRITE_ENABLE      0X06 //дʹ��
#define FLASH_CMD_WRITE_DISENABLE   0X04 //д����
#define FLASH_CMD_READ_STATUS_REG1  0X05 //��״̬�Ĵ���1
#define FLASH_CMD_WRITE_STATUS_REG  0X01 //д״̬�Ĵ���
#define FLASH_CMD_ERASE_SECTOR      0X20 //��������
#define FLASH_CMD_PAGE_PROGRAM      0X02 //ҳ���
#define FLASH_CMD_READ              0X03 //������


#define FLASH_PAGE_SIZE 256  
#define FLASH_SECTOR_PAGE  16
#define FLASH_SECTOR_SIZE  FLASH_PAGE_SIZE *  FLASH_SECTOR_PAGE


#define WRITE_STATUS_REG_TIME_OUT  15
#define PAGE_TIME_OUT               5
#define SECTOR_ERASE_TIME_OUT      500
#define CHIP_ERASE_TIME_OUT        30000

#define FLASH_GETSECTOR_STATRTADDR(ADDR) (ADDR & ~0XFFFUL)  //�����׵�ַ
#define FLASH_GETPAGE_STATRADDR(ADDR) (ADDR & ~ 0XFFUL)    //ҳ�׵�ַ    
#define FLASH_GETSECTOR_OFFSET(ADDR) (ADDR &0XFFFUL )    // ������ƫ����

#define DUMMY_BYTE  0XFF  //��Ч���ֽ�


//#define BACK_UP_SECTORADDR  0X7FF000  //���������ĵ�ַ   // W25Q64
#define BACK_UP_SECTORADDR  0X3FF000  //���������ĵ�ַ   // W25Q632

extern void Flash_Init(void);
extern void Flash_ID_Printf(void);
extern void Flash_Wait_Busy(uint16 Time_out);
extern void Flash_Erase_Sector(uint32 Addr);
extern void Flash_Erase_NSector(uint32 Addr,uint16 Setcor_Num);
extern void Flash_Write_NBytesInPageNoErase(uint32 Addr,uint8 *Write_Buff,uint16 Cnt);
extern void Flash_Write_NBytesNoErase(uint32 Addr,uint8 *Write_Buff,uint32 Cnt);
extern void Flash_Read_NBytes(uint32 Addr,uint8 *Read_Buff,uint32 Cnt);
extern void Flash_WriteNBytesInSector(uint32 Addr,uint8 *Write_Buff,uint16 Cnt);
extern void Flash_Write_NBytes(uint32 Addr,uint8 *Write_Buff,uint32 Cnt);

#endif



