#ifndef __KEY_H_
#define __KEY_H_


#include "type.h"


#define KEY_INPUT_STATE  PC4



enum
{
    NO_KEY = 0,
    KEY_OK,
};


extern uint8 gb_RootKeyOption;
extern uint8 gb_KeyLocation;

extern uint8 *gb_RootKeyAddr;
extern uint8 gb_LcddisplayTimeout,display_mesg;


extern void Key_Io_Init(void);
extern uint8 Key_Scan(void);
extern void Task_Key(void);

extern void Lcd_display_Mseg(uint8 Key_Meg);


#endif

