#ifndef __WB_Gneiss_Sample_Code_LLD_H_
#define __WB_Gneiss_Sample_Code_LLD_H_


#include "type.h"



enum
{
	RESULT_ERR =0,
	RESULT_OK =1,
};



uint8 W74M_Write_Read_Byte(uint8 Write_data);


unsigned int WB_RPMC_ReadRPMCstatus(unsigned int checkall);
void WB_RPMC_ReqCounter(unsigned int cadr, unsigned char *hmackey,unsigned char *input_tag);
unsigned int WB_RPMC_WrRootKey(unsigned int cadr,unsigned char *rootkey);
unsigned int WB_RPMC_UpHMACkey(unsigned int cadr,unsigned char *rootkey,unsigned char *hmac4,unsigned char *hmackey);
unsigned int WB_RPMC_IncCounter(unsigned int cadr,unsigned char *hmackey,unsigned char *input_tag);
unsigned char WB_RPMC_Challenge(unsigned int cadr, unsigned char *hmackey,unsigned char *input_tag);

uint8 RPMC_Write_RootKey(uint8 RootKey_location,uint8 *Root_key);
uint8 UpHMACKey_IncCounter(uint8 RootKey_location);      //���ĺ���



#endif

