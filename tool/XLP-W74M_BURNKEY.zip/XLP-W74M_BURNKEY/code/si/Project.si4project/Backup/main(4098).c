#include "Nano1X2Series.h"
#include "type.h"
#include "usart_user.h"
#include "delay.h"
#include "timer_user.h"
#include "lcd_User.h"
#include "LCDLIB.h"
#include "lcd.h"
#include "led.h"
#include "key.h"
#include "system.h"
#include "WB_Gneiss_Sample_Code_LLD.h"
#include "spi_user.h"

/***************************************����˵��*********************************************
*  �������ƣ�XLP-W74M_BURNKEY-V01-20180918
*  �����汾��V01
*  ��������: 20180918
*  ��     �ߣ��±�
*  ����˵��������NUVOTON Nano112ƽ̨
*  ������;�������¼�ξ����W74M��KEY��¼����֤����
*  ����˵����
*  ��     ����KEY�����ݣ��û����޸�RootKey.h�ļ��� ��¼λ�ÿ��޸�RootKey.h  �� ROOTKEY_LOCATION�궨��
		     У��������޸� system.h �� W74M_VERIFY_TIME �궨��
********************************************************************************************/





#define DEBUG_SYS_CLOCK 0

/********************************************************************************************
*  �� �� ����System_Init
*  ��     ��:  ϵͳ��ʼ��
*  �����������
*  �����������
*  �� �� ֵ:    ��
*  ��     ��:  �±�
*  �������:     2018-09-29
*  ע������:     ��Ҫ������ϵͳʱ��
********************************************************************************************/
void System_Init(void)
{
    /*---------------------------------------------------------------------------------------------------------*/
    /* Init System Clock                                                                                       */
    /*---------------------------------------------------------------------------------------------------------*/
    /* Unlock protected registers */
    SYS_UnlockReg();

    /* Enable External XTAL (4~24 MHz) */
    CLK->PWRCTL |= (0x1 << CLK_PWRCTL_HXT_EN_Pos); // HXT Enabled

    /* Waiting for 12MHz clock ready */
    CLK_WaitClockReady( CLK_CLKSTATUS_HXT_STB_Msk);

	/* Enable External XTAL (32 KHz) */
    CLK_EnableXtalRC(CLK_PWRCTL_LXT_EN_Msk);  //LXT Enable
    
    /* Waiting for 32KHz clock ready */
    CLK_WaitClockReady( CLK_CLKSTATUS_LXT_STB_Msk);

    /* Switch HCLK clock source to XTAL */
    CLK->CLKSEL0 &= ~CLK_CLKSEL0_HCLK_S_Msk;
    CLK->CLKSEL0 |= CLK_CLKSEL0_HCLK_S_HXT;

    /* Enable IP clock */
  /*  CLK->APBCLK |= CLK_APBCLK_UART0_EN; // UART0 Clock Enable
    CLK->APBCLK |= CLK_APBCLK_UART1_EN; // UART1 Clock Enable*/

    /* Select IP clock source */
    CLK->CLKSEL1 &= ~CLK_CLKSEL1_UART_S_Msk;
    CLK->CLKSEL1 |= (0x0 << CLK_CLKSEL1_UART_S_Pos);// Clock source from external 12 MHz or 32 KHz crystal clock

    /* Update System Core Clock */
    /* User can use SystemCoreClockUpdate() to calculate PllClock, SystemCoreClock and CycylesPerUs automatically. */
    
	CLK_EnablePLL(CLK_PLLCTL_PLL_SRC_HXT,SYSTEM_CORECLOCK);  //����PLLʱ��Ϊϵͳʱ��
    CLK_SetHCLK(CLK_CLKSEL0_HCLK_S_PLL, CLK_HCLK_CLK_DIVIDER(1));
	SystemCoreClockUpdate();

    /*---------------------------------------------------------------------------------------------------------*/
    /* Init I/O Multi-function                                                                                 */
    /*---------------------------------------------------------------------------------------------------------*/
    /* Set PB multi-function pins for UART0 RXD and TXD  */
 /*   SYS->PB_L_MFP &= ~(SYS_PB_L_MFP_PB0_MFP_Msk|SYS_PB_L_MFP_PB1_MFP_Msk);
    SYS->PB_L_MFP |=  (SYS_PB_L_MFP_PB0_MFP_UART0_TX|SYS_PB_L_MFP_PB1_MFP_UART0_RX);*/

    /* Set PB multi-function pins for UART1 RXD, TXD, RTS, CTS  */
 /*   SYS->PB_L_MFP &= ~(SYS_PB_L_MFP_PB4_MFP_Msk | SYS_PB_L_MFP_PB5_MFP_Msk |
                       SYS_PB_L_MFP_PB6_MFP_Msk | SYS_PB_L_MFP_PB7_MFP_Msk);
    SYS->PB_L_MFP |= (SYS_PB_L_MFP_PB4_MFP_UART1_RTS | SYS_PB_L_MFP_PB5_MFP_UART1_RX |
                      SYS_PB_L_MFP_PB6_MFP_UART1_TX  | SYS_PB_L_MFP_PB7_MFP_UART1_CTS);*/

    /* Lock protected registers */
    SYS_LockReg();
}


#if DEBUG_SYS_CLOCK
void System_Clock_Printf(void)
{
	uint32 Freq_Value;
	Freq_Value = CLK_GetCPUFreq();
	printf("CPUFreq = %d HZ\r\n",Freq_Value);
	Freq_Value = CLK_GetHCLKFreq();
	printf("HCLKFreq = %d HZ\r\n",Freq_Value);
	Freq_Value = CLK_GetHXTFreq();
	printf("HXTFreq = %d HZ\r\n",Freq_Value);
	Freq_Value = CLK_GetLXTFreq();
	printf("LXTFreq = %d HZ\r\n",Freq_Value);
	
	Freq_Value = CLK_GetPLLClockFreq();
	printf("PLLClockFreq = %d HZ\r\n",Freq_Value);
	Freq_Value = CLK_GetPCLKFreq();
	printf("tPCLKFreq = %d HZ\r\n",Freq_Value);
}
#endif

int main(void)
{
	old_RootKeyOption = gb_RootKeyOption;
	System_Init();
	SYS_UnlockReg();
	System_Io_Init();
    SysTick_Init();
    SPI_Configuration();
    Led_Io_Init();
	USART0_Configuration(115200);
	#if DEBUG_SYS_CLOCK
	System_Clock_Printf();
	#endif
	
	Timer0_Configuration(160,2000); //10ms
	Lcd_Configuration();
	Key_Io_Init();
	LCDLIB_Printf(0, (char *)&RootKey_indicate[0][0]);
   // EXTI0_PA2_Init();
    printf("system runing\r\n");
    while(1)
    {
		Task_Key();
		Task_System();  
		
    }
}


