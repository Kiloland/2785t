#ifndef __SOFT_VERVERIFY_H_
#define __SOFT_VERVERIFY_H_

#include "type.h"


#define SOFT_VERVEIFY_FUNCTION  1

#if SOFT_VERVEIFY_FUNCTION

#define SOFT_VERVEIFY_BAUD  9600  //���ڲ�����9600
extern void Soft_VerVeifyPrintf(void);


#endif

#endif


