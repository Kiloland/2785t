#ifndef __SYSTEM_H_
#define __SYSTEM_H_

#include "type.h"


/*У��������û����������޸�*/
#define W74M_VERIFY_TIME   2


enum
{
	IS_SYS_IDIE=0,
	IS_SYS_KEY_CHECK_ERROR,
	IS_SYS_START_CHECK,
	IS_SYS_START,
	IS_SYS_WRITE_ROOT_KEY,
	IS_SYS_VERIFY,
	IS_SYS_JUDGE_RESULT,
};


#define OK_OUT_HIGH	 PE4=1
#define OK_OUT_LOW 	 PE4=0	

#define BUSY_OUT_HIGH	PE5=1
#define BUSY_OUT_LOW 	PE5=0	


#define NG_OUT_HIGH		PA0=1
#define NG_OUT_LOW 		PA0=0

#define ST_OUT_HIGH		PE7=1
#define ST_OUT_LOW 		PE7=0


#define ST_IN_STATE PE7

#define W74M_CS_OUT_HIGH  PE3=1
#define W74M_CS_OUT_LOW   PE3=0




extern uint8 RootKey_indicate[][6];
extern uint8 old_RootKeyOption;


extern void System_Io_Init(void);
extern void Task_System(void);

extern void EXTI0_PA2_Init(void);


#endif

