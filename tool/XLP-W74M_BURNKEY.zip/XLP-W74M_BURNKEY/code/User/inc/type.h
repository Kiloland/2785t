#ifndef __TYPE_H_
#define __TYPE_H_

#include "Nano1X2Series.h"
#include <stdio.h>


typedef uint8_t uint8;
typedef uint16_t uint16;
typedef uint32_t uint32;
typedef int32_t  int32;
typedef int16_t int16;
typedef int8_t  int8;
typedef int32_t  sint32;
typedef int16_t sint16;
typedef int8_t  sint8;


typedef uint8 byte;

#endif



