#ifndef __DELAY_H_
#define __DELAY_H_

#include "Nano1X2Series.h"
#include "type.h"


#define MS_BASE  4000
#define US_BASE  4

#define SYSTICK_INTERRUPT_FUNTION     0  



#if SYSTICK_INTERRUPT_FUNTION
extern void SysTick_Interrupt_Init(uint16 nms);
#endif

extern void SysTick_Init(void);
extern void delay_ms(uint16 nms);
extern void delay_us(uint32 nus);
extern void delay_nms(uint32 nms);

#endif


