#ifndef __RTC_USER_H_
#define __RTC_USER_H_

#include "M480.h"
#include "type.h"





extern S_RTC_TIME_DATA_T gb_Date_Time;

extern uint8 RTC_Init(void);
extern void Task_RTC(void);



#endif

