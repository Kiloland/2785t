#ifndef __SPI_USER_H_
#define __SPI_USER_H_


#include "type.h"

#define SPI_IO_SIMULATE_EN   1

#if SPI_IO_SIMULATE_EN

#define SCL_OUT_HIGH  (PE2 = 1)
#define SCL_OUT_LOW   (PE2 = 0)

#define MOSI_OUT_HIGH (PE0 = 1)
#define MOSI_OUT_LOW  (PE0 = 0)

#define MISO_STATE    (PE1)


extern void SPI_Configuration(void);


#endif

#define DUMMY_BYTE 0X00

extern uint8 SPI_Write_Read_Byte(uint8 Write_data);

#endif





