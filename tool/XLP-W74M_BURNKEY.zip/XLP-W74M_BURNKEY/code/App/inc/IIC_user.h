#ifndef __IIC_USER_H_
#define __IIC_USER_H_

#include "Nano1X2Series.h"
#include "type.h"


#define ACK_OK  0
#define NO_ACK  1

#define IIC_SDA_STATE  PG1

#define IIC_SDA_OUT_LOW   (PG0=0)
#define IIC_SDA_OUT_HIGH  (PG0=1)

#define IIC_SCL_OUT_LOW   (PG1=0)
#define IIC_SCL_OUT_HIGH  (PG1=1)

#define IIC_SDA_OUT()   GPIO_SetMode(PG,BIT1, GPIO_MODE_OUTPUT)
#define IIC_SDA_IN()    GPIO_SetMode(PG,BIT1, GPIO_MODE_INPUT)

extern void IIC_Io_Init(void);
extern void IIC_Start(void);
extern void IIC_Stop(void);
extern void IIC_Write_Byte(uint8 Byte);
extern void IIC_Write_Ack(uint8 Ack);
extern uint8 IIC_Read_Byte(void);
extern uint8 IIC_Wait_Ack(void);

#endif

