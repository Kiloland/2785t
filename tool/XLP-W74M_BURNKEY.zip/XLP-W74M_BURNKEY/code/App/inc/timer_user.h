#ifndef __TIMER_H_
#define __TIMER_H_

#include "Nano1X2Series.h"
#include "type.h"

extern void Timer0_Configuration(uint8 PSC,uint32 CMP_Data);



#endif


