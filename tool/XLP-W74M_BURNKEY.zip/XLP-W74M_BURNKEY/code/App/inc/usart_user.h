#ifndef __USART_H_
#define __USART_H_

#include "type.h"
#include "Nano1X2Series.h"

extern uint8 gb_PCRx_Buff[10],gb_PCRx_EndFlag,gb_PCRX_Timeout;

extern void USART0_Configuration(uint32 Baud);
extern void PCTx_String(uint8 *String);
extern void Task_PC(void);



#endif
